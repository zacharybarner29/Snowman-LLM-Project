// Word banks copied from Snowman_project_Zachary_Barner.ipynb.
const wordBanks = {
  en: {
    easy: ["apple", "house", "dog", "cat", "tree", "book", "fish", "ball", "car", "milk", "sun", "moon", "star", "cake", "bird", "shoe", "chair", "water", "pizza", "phone", "school", "horse", "bread", "cloud", "beach"],
    hard: ["adventure", "butterfly", "calendar", "champion", "chocolate", "dinosaur", "discovery", "elephant", "giraffe", "happiness", "imagination", "journey", "knowledge", "mysterious", "nightmare", "penguin", "pineapple", "rainbow", "restaurant", "squirrel", "thunderstorm", "treasure", "umbrella", "volcano"]
  },
  fr: {
    easy: ["pomme", "maison", "chien", "chat", "arbre", "livre", "poisson", "balle", "voiture", "lait", "soleil", "lune", "etoile", "gateau", "oiseau", "chaussure", "chaise", "eau", "pizza", "telephone", "ecole", "cheval", "pain", "nuage", "plage"],
    hard: ["aventure", "papillon", "calendrier", "champion", "chocolat", "dinosaure", "decouverte", "elephant", "girafe", "bonheur", "imagination", "voyage", "connaissance", "mysterieux", "cauchemar", "pingouin", "ananas", "restaurant", "ecureuil", "orage", "tresor", "parapluie"]
  },
  es: {
    easy: ["manzana", "casa", "perro", "gato", "arbol", "libro", "pez", "pelota", "coche", "leche", "sol", "luna", "estrella", "pastel", "pajaro", "zapato", "silla", "agua", "pizza", "telefono", "escuela", "caballo", "pan", "nube", "playa"],
    hard: ["aventura", "mariposa", "calendario", "campeon", "chocolate", "dinosaurio", "descubrimiento", "elefante", "jirafa", "felicidad", "imaginacion", "viaje", "conocimiento", "misterioso", "pesadilla", "pinguino", "pina", "arcoiris", "restaurante", "ardilla", "tormenta", "tesoro", "paraguas", "volcan"]
  }
};

const translations = {
  en: { difficulty: "Difficulty", language: "Language", easy: "Easy", hard: "Hard", newGame: "New game", guesses: "GUESSES LEFT", missed: "Missed letters", empty: "No wrong guesses yet", length: "Show word length", lengthHelp: "Display the number of letters", guessWord: "Guess word", wordPlaceholder: "Guess the whole word…", hint: "Hint · 3 guesses", hintUsed: "Hint used", win: "You win", playAgain: "Play again", score: "SCORE", lossTitle: "You lost", lossMessage: "The snowman melted away. He’ll be missed.", correctWord: "THE CORRECT WORD" },
  fr: { difficulty: "Difficulté", language: "Langue", easy: "Facile", hard: "Difficile", newGame: "Nouvelle partie", guesses: "ESSAIS RESTANTS", missed: "Lettres manquées", empty: "Aucune erreur pour le moment", length: "Afficher la longueur", lengthHelp: "Afficher le nombre de lettres", guessWord: "Deviner le mot", wordPlaceholder: "Devinez le mot entier…", hint: "Indice · 3 essais", hintUsed: "Indice utilisé", win: "Bravo !", playAgain: "Rejouer", score: "SCORE", lossTitle: "Perdu", lossMessage: "Le bonhomme a fondu. Il va nous manquer.", correctWord: "LE BON MOT" },
  es: { difficulty: "Dificultad", language: "Idioma", easy: "Fácil", hard: "Difícil", newGame: "Nuevo juego", guesses: "INTENTOS RESTANTES", missed: "Letras fallidas", empty: "Aún no hay errores", length: "Mostrar longitud", lengthHelp: "Mostrar número de letras", guessWord: "Adivinar", wordPlaceholder: "Adivina la palabra…", hint: "Pista · 3 intentos", hintUsed: "Pista usada", win: "¡Ganaste!", playAgain: "Jugar otra vez", score: "PUNTUACIÓN", lossTitle: "Perdiste", lossMessage: "El muñeco se derritió. Lo vamos a extrañar.", correctWord: "LA PALABRA CORRECTA" }
};

const alphabet = "abcdefghijklmnopqrstuvwxyz".split("");
const $ = id => document.getElementById(id);
const state = { answer: "", guessed: new Set(), revealed: new Set(), wrong: [], wrongWord: false, guessesSpent: 0, round: 0, finished: false, won: false, hintUsed: false, language: "en" };

function text() { return translations[state.language]; }

function startGame() {
  state.language = $("language").value;
  const bank = wordBanks[state.language][$("difficulty").value];
  state.answer = bank[Math.floor(Math.random() * bank.length)];
  state.guessed.clear();
  state.revealed.clear();
  state.wrong = [];
  state.wrongWord = false;
  state.guessesSpent = 0;
  state.finished = false;
  state.won = false;
  state.hintUsed = false;
  state.round++;
  $("word-guess").value = "";
  render();
}

function render() {
  const remaining = 6 - state.guessesSpent;
  const winning = state.finished && state.won;
  const losing = state.finished && !state.won;
  $("game-card").classList.toggle("is-won", winning);
  $("game-card").classList.toggle("is-lost", losing);
  $("game-play").hidden = state.finished;
  $("win-screen").hidden = !winning;
  $("loss-screen").hidden = !losing;
  $("guess-count").textContent = remaining;
  $("guess-progress").style.width = `${remaining / 6 * 100}%`;
  const melt = state.wrongWord ? 8 : Math.round((state.wrong.length / 6) * 8);
  $("snow-stage").dataset.melt = String(melt);
  $("missed-count").textContent = String(state.wrong.length).padStart(2, "0");
  $("missed-out-of").textContent = "/ 06";

  const missed = $("missed-list");
  missed.replaceChildren();
  if (!state.wrong.length) {
    const empty = document.createElement("span");
    empty.className = "empty-copy";
    empty.textContent = text().empty;
    missed.append(empty);
  } else {
    state.wrong.forEach(letter => {
      const item = document.createElement("span");
      item.className = "missed-letter";
      item.textContent = letter.toUpperCase();
      missed.append(item);
    });
  }

  const slots = $("word-slots");
  slots.replaceChildren();
  [...state.answer].forEach((letter, index) => {
    const slot = document.createElement("span");
    slot.className = "word-slot";
    slot.textContent = state.guessed.has(letter) || state.revealed.has(index) || state.finished ? letter.toUpperCase() : "";
    slots.append(slot);
  });
  $("word-hint").textContent = `${state.answer.length} ${state.language === "fr" ? "lettres" : state.language === "es" ? "letras" : "letters"}`;
  $("word-hint").hidden = !$("length-toggle").checked;

  const keyboard = $("keyboard");
  keyboard.replaceChildren();
  alphabet.forEach(letter => {
    const key = document.createElement("button");
    key.type = "button";
    key.className = "key";
    key.textContent = letter.toUpperCase();
    key.disabled = state.guessed.has(letter) || state.finished;
    if (state.guessed.has(letter)) key.classList.add(state.answer.includes(letter) ? "correct" : "wrong");
    key.addEventListener("click", () => guessLetter(letter));
    keyboard.append(key);
  });

  $("hint-button").textContent = state.hintUsed ? text().hintUsed : text().hint;
  $("hint-button").disabled = state.hintUsed || state.finished || remaining < 3;
  $("word-guess").disabled = state.finished;
  $("word-submit").disabled = state.finished;
  $("word-guess").placeholder = text().wordPlaceholder;
  $("word-submit").textContent = text().guessWord;
  $("guess-label").textContent = text().guesses;
  $("missed-title").textContent = text().missed;
  $("difficulty-label").textContent = text().difficulty;
  $("language-label").textContent = text().language;
  $("new-game-label").textContent = text().newGame;
  $("length-option").textContent = text().length;
  $("difficulty").options[0].text = text().easy;
  $("difficulty").options[1].text = text().hard;
  $("win-title").textContent = text().win;
  $("score-label").textContent = text().score;
  $("win-again").textContent = text().playAgain;
  $("loss-title").textContent = text().lossTitle;
  $("loss-message").textContent = text().lossMessage;
  $("correct-word-label").textContent = text().correctWord;
  $("loss-again").textContent = text().playAgain;
  document.title = `Frostline — ${text().win}`;
}

function finish(won) {
  state.finished = true;
  state.won = won;
  if (won) {
    const score = Math.floor(((6 - state.guessesSpent) / 6) * 100);
    $("win-word").textContent = state.answer.toUpperCase();
    $("score-value").textContent = `${score}%`;
  } else {
    $("loss-word").textContent = state.answer.toUpperCase();
  }
  render();
}

function guessLetter(letter) {
  if (state.finished || state.guessed.has(letter)) return;
  state.guessed.add(letter);
  if (!state.answer.includes(letter)) {
    state.wrong.push(letter);
    state.guessesSpent++;
  }
  const complete = [...state.answer].every((char, index) => state.guessed.has(char) || state.revealed.has(index));
  if (complete) return finish(true);
  if (state.guessesSpent >= 6) return finish(false);
  render();
}

function useHint() {
  if (state.finished || state.hintUsed || 6 - state.guessesSpent < 3) return;
  state.hintUsed = true;
  state.revealed.add(0);
  state.revealed.add(1);
  state.guessesSpent += 3;
  const complete = [...state.answer].every((char, index) => state.guessed.has(char) || state.revealed.has(index));
  if (complete) return finish(true);
  if (state.guessesSpent >= 6) return finish(false);
  render();
}

function submitWord(event) {
  event.preventDefault();
  if (state.finished) return;
  const guess = $("word-guess").value.trim().toLowerCase();
  if (!guess) return;
  if (guess === state.answer) finish(true);
  else {
    state.wrongWord = true;
    state.guessesSpent = 6;
    finish(false);
  }
}

function showToast(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2600);
}

$("new-game").addEventListener("click", startGame);
$("win-again").addEventListener("click", startGame);
$("loss-again").addEventListener("click", startGame);
$("difficulty").addEventListener("change", startGame);
$("language").addEventListener("change", startGame);
$("length-toggle").addEventListener("change", () => { $("word-hint").hidden = !$("length-toggle").checked; });
$("hint-button").addEventListener("click", useHint);
$("word-form").addEventListener("submit", submitWord);
document.addEventListener("keydown", event => {
  if (/^[a-z]$/i.test(event.key) && event.target.tagName !== "INPUT") guessLetter(event.key.toLowerCase());
});
startGame();
